import './App.css';
import AddUser from "./components/AddUser"
function App() {
  return (
    <div className="container-fluid">
      <AddUser />
    </div>
  );
}

export default App;
