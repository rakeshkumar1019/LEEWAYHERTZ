import axios from 'axios'
import React, { useState } from 'react'

const AddUser = () => {
    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')
    const [phone, setPhone] = useState('')
    const [Url, setUrl] = useState('')
    const [serverRes, setServerResp] = useState(false)
    const [res, setRes] = useState({})

    const onChangeFile = (e) => {
        setUrl(e.target.files[0])
    }

    const onSubmit = async (e) => {
        e.preventDefault()
        const formData = new FormData()
        formData.append("firstName", firstName)
        formData.append("lastName", lastName)
        formData.append("email", email)
        formData.append("phone", phone)
        formData.append("imageUrl", Url)

        await axios.post("http://localhost:8000/api/signup", formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
            .then(res => {
                console.log(res.data)
                setRes(res.data)
                setServerResp(true)
            })
    }
    return (
        <div className="conatiner">
            {!serverRes ? <div className="w-75 mx-auto shadow p-5">
                <h1 className="text-center mb-4">Add a User</h1>
                <form onSubmit={e => onSubmit(e)} encType="multipart/form-data">
                    <div className="form-group">
                        <div className="form-group">
                            <label htmlFor="exampleInputPassword1">Enter FirstName</label>
                            <input
                                type="text"
                                className="form-control"
                                name="firstName"
                                value={firstName}
                                onChange={e => setFirstName(e.target.value)}

                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="exampleInputPassword1">Enter Last Name</label>
                            <input
                                type="text"
                                className="form-control"
                                name="lastName"
                                value={lastName}
                                onChange={e => setLastName(e.target.value)}

                            />
                        </div>
                        <label htmlFor="exampleInputEmail1">Email address</label>
                        <input type="email"
                            className="form-control"
                            name="email"
                            value={email}
                            onChange={e => setEmail(e.target.value)}

                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="exampleInputPassword1">Phone</label>
                        <input type="phone"
                            className="form-control"
                            name="phone"
                            value={phone}
                            onChange={e => setPhone(e.target.value)}

                        />
                    </div>
                    <div className="custom-file mb-4">
                        <input
                            type="file"
                            className="custom-file-input"
                            id="customFile"
                            filename="imageUrl"
                            onChange={onChangeFile}
                        />
                        <label className="custom-file-label" htmlFor="customFile">
                            choose image
                        </label>
                    </div>
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
            </div> : null}
            {serverRes ? <div className="card" style={{ width: "30rem", margin: "0 auto", float: "none", 'margin-bootom': "10px " }} >
                <h3 className="card-title display-3" style={{ textAlign: "center" }}>  USER DETAILS </h3>
                <img src={`/uploads/${res.imageurl}`} className="card-img-top" alt="..." />
                <div className="card-body">
                    <h5 className="card-title"> <strong>First Name</strong>: {res.firstname}</h5>
                    <h5 className="card-title"><strong>Last Name</strong>:  {res.lastName}</h5>
                    <h5 className="card-title"><strong>Eamil</strong>: {res.email}</h5>
                    <h5 className="card-title"><strong>Phone</strong>:{res.phone}</h5>
                </div>
                <button onClick={() => setServerResp(false)} className="btn btn-primary">Add New User</button>

            </div> : null
            }
        </div >
    )
}

export default AddUser
