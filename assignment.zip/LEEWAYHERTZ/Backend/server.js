require('dotenv').config()
const express = require("express")
var bodyParser = require('body-parser')
const mongoose = require("mongoose")
const multer = require("multer")
const cors = require("cors")
const expUploads = require("express-upload")
const app = express()
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())
app.use(cors())

//my routes
const userRoutes = require("./routes/user")


//DBCONNECTION
mongoose.connect(process.env.DATABASE,
    {
        useUnifiedTopology: true,
        useNewUrlParser: true,
        useCreateIndex: true
    }).then(() => {
        console.log("DB CONNECTED")
    })


//my routes
app.use("/api", userRoutes)



//PORT
const port = process.env.PORT || 8000
app.listen(port, () => {
    console.log(`app is running at ${port}`)
})
