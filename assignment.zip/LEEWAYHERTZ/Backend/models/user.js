const mongoose = require("mongoose")
let userSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: true,
        maxlength: 30,
        trim: true
    },
    lastName: {
        type: String,
        maxlength: 30,
        trim: true,
    },
    email: {
        type: String,
        trim: true,
        required: true,
        unique: true,
    },
    phone: {
        type: Number,
        required: true,
        maxlength: 10
    },
    imageUrl: {
        type: String,
        required: true,
    }
},
    { timestamps: true }
)
module.exports = mongoose.model("User", userSchema)
