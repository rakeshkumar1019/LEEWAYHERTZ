const express = require("express")
const multer = require("multer")
const router = express.Router()
const { signup } = require("../controllers/user")
const storage = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, "./../client/public/uploads/")
    },
    filename: (req, file, callback) => {
        callback(null, file.originalname)
    }
})
const upload = multer({ storage: storage })

router.post(
    "/signup", upload.single("imageUrl"), signup
);

module.exports = router