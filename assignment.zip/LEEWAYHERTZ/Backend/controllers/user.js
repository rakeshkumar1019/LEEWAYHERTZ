const User = require("../models/user")

exports.signup = (req, res) => {
    const newUser = new User({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phone: req.body.phone,
        imageUrl: req.file.filename
    })
        .save((err, newUser) => {
            if (err) {
                return res.status(400).json({
                    err: "NOT able to save user in DB"
                })
            }
            res.json({
                id: newUser._id,
                firstname: newUser.firstName,
                lastName: newUser.lastName,
                phone: newUser.phone,
                email: newUser.email,
                imageurl: newUser.imageUrl,
            })
        })



}